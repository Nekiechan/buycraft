BuyCraft (port for PocketMine-MP)
===========
This port includes all the functionality from BuyCraft for bukkit (excluding signs and GUI).


###BuyCraft TOS Compliance
> The API located at http://api.buycraft.net may be used for any purpose other than websites who are in competition with the services we provide.

###BuyCraft Plugin License Compliance
It is not possible to comply with the license as BuyCraft has reserved all rights to the software. In order to create an effective port I had to look over the working of the API (the BuyCraft source) which is against the license (I suppose). This is silly as in order to use the API (as permitted above) one must look over it's implementation.
