---- DISCLAIMER ------------------------

This is a plugin port of the BuyCraft plugin for Bukkit. The port was done using the BuyCraft source
and implements licensed BuyCraft features. The BuyCraft source has been used sparingly and all code has
been written from scratch .

YOU ARE WHOLLY RESPONSIBLE FOR YOUR USAGE OF THIS PLUGIN. IF YOU ARE DISAGREE TO THIS
PLEASE REMOVE THE PLUGIN.

THIS PLUGIN IS NOT ENDORSED OR SUPPORTED IN ANY WAY BY BUYCRAFT, IT'S SUBSIDIARIES OR IT'S PARTNERS.

---- Buycraft Plugin ------------------------

For setup instructions please visit https://buycraft.net.

Upgrade your account and receive many more awesome features by going to https://server.buycraft.net/plans.


--- INSTALLATION -----------------------------------------------------------

Please run the command "/buycraft secret <Secret key>" in the console. To find your 
secret key, go to http://server.buycraft.net and visit the servers page under the webstore 
section. Refer to installation videos and tutorials available on http://buycraft.net for more help/info.

---- RECENT PAYMENT SIGNS --------------------------------------------------

This port does not support recent payment signs.

---- PERMISSION NODES -----------------------------------------------------

Listed below are the permission nodes for the plugin:

	buycraft.admin - Enables use of the "/buycraft <reload/forcecheck/secret>" commands